^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package neobotix_usboard_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.3.1 (2018-12-07)
------------------
* Merge pull request `#31 <https://github.com/astuff/astuff_sensor_msgs/issues/31>`_ from astuff/maint/add_urls
* Adding URLs to package.xml files.
* Contributors: Daniel-Stanek, Joshua Whitley

2.3.0 (2018-10-04)
------------------

2.2.2 (2018-08-30)
------------------

2.2.1 (2018-08-08)
------------------

2.1.0 (2018-05-14)
------------------
* added sensors list message.
* removed unconfirmed status addition from neobotix msg
* deleted 4 sensor message and renamed data1sensor to SensorData
* Adding Data1Sensor message to support individual topics per sensor
* Updating package.xml to format 2.
* Standardizing package.xml files.
* Initial commit.
* Contributors: Joe Kale, Joshua Whitley, Kyle Rector
